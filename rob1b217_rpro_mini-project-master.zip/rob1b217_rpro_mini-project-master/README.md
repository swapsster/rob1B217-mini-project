# rob1B217_rpro_mini-project

This is the mini-project, for the robotics programming exam, provided by group rob1B217, 1st. semester, Robotics at Aalborg University, 2016.

The provided code is made by the group, solely for the aforementioned exam.
